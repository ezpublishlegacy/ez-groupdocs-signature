<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocssignature
ModuleList[]=groupdocssignature
*/ ?>